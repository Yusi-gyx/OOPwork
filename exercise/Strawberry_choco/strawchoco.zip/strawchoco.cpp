#include "strawchoco.h"
#include "event.h"

void Chocolate::zoo(EventInterface* peer)
{
    increase_mood(5);
    // if(dynamic_cast<Chocolate*>(peer))  //同伴是巧克力
    // {
    //     static_cast<Chocolate*>(peer)->visited_zoo.push_back(this);
    // }
    visited_zoo.push_back(peer);
} 

void Chocolate::shop(EventInterface* peer)
{
    increase_mood(1);
    // if(dynamic_cast<Strawberry*>(peer))  //同伴是草莓
    // {
    //     static_cast<Strawberry*>(peer)->visited_shop.push_back(this);
    // }
}

void Chocolate::birthday()
{
    increase_mood(1);
    int n = visited_zoo.size();
    if(n)
    {
        increase_mood(5);
        visited_zoo [n - 1]->increase_mood(1);
    }
}

void Strawberry::zoo(EventInterface* peer)
{
    increase_mood(1);
    if(dynamic_cast<Chocolate*>(peer)) //同伴是巧克力
    {
        increase_mood(5);
        // static_cast<Chocolate*>(peer)->visited_zoo.push_back(this);
    }
}

void Strawberry::shop(EventInterface* peer)
{
    increase_mood(5);
    visited_shop.insert(peer);
    if(dynamic_cast<Chocolate*>(peer)) //同伴是巧克力
    {
        increase_mood(5);
    }
    // else
    // {
    //     static_cast<Strawberry*>(peer)->visited_shop.push_back(this);
    // }
}

void Strawberry::birthday()
{
    int n = visited_shop.size();
    increase_mood(n);
    if(n)
    {
        for(auto x: visited_shop)
        {
            x->increase_mood(1);
        }
    }
}